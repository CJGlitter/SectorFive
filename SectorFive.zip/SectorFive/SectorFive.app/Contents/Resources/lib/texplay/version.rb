module TexPlay
  VERSION = "0.4.4.pre"
end
